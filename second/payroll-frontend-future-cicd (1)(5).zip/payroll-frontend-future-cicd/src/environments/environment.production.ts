export const environment = {
    production:true,
    isMockEnabled:true,
    apiUrl:'https://payapi.vprc.in/api/v1/'
};
