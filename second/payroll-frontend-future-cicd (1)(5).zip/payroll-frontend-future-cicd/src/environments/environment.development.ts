export const environment = {
    production:false,
    isMockEnabled:true,
    // apiUrl:'http://localhost:3000/api/v1/'
    apiUrl:'https://payapi.vprc.in/api/v1/'
};
